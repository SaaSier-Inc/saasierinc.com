SAASIER INC LOGO ASSETS (Brand Kit 2026)

Contents
- PNG/  Raster logos for print and digital use
- SVG/  Vector logos for scalable use

Files
- SaaSier_Logo_Horizontal_Primary    Primary wordmark for light backgrounds
- SaaSier_Logo_Horizontal_Reversed   Wordmark for navy / dark backgrounds
- SaaSier_Logo_Stacked_Primary       Stacked lockup for light backgrounds
- SaaSier_Logo_Stacked_Reversed      Stacked lockup for navy / dark backgrounds
- SaaSier_Mark_Metallic_Gold         Monogram mark, metallic gold
- SaaSier_Mark_Flat_Gold             Monogram mark, flat gold
- SaaSier_Mark_Navy                  One-color monogram, midnight navy
- SaaSier_Mark_White                 One-color monogram, white (for dark backgrounds)

Usage
- Clear space: keep at least the height of the gold mark around every side of the logo.
- Minimum size: 120px wide for the wordmark, 24px for the monogram.
- Never stretch, rotate, add shadows, alter proportions, or recolor individual
  components outside the approved palette.

Core colors
- Midnight Navy #071A36
- Founder Gold  #D4AF4A
- Operating Slate #334155
- Cloud #F3F4F6
- White #FFFFFF

Media contact: press@saasierinc.com
Full brand guide: https://saasierinc.com/assets/saasier-brand-guidelines.pdf
